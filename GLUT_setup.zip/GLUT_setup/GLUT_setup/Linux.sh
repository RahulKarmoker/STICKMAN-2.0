#!/bin/bash

echo "Running automated Script for setting up OpenGl environment in Ubuntu 32 bit version using freeglut3"


echo "installing build-essential"
sudo apt-get install build-essential
echo "installing Freeglut"
sudo apt-get install freeglut3
echo "installing Freeglut development"
sudo apt-get install freeglut3-dev
echo "installing Freeglut debug"
sudo apt-get install freeglut3-dbg


echo "installing glew-utils"
sudo apt-get install glew-utils

echo "installing libglew1.10 and libglewmx1.10"
sudo apt-get install libglew1.10
sudo apt-get install libglew-dev
sudo apt-get install libglew-dbg
sudo apt-get install libglewmx1.10
sudo apt-get install libglewmx-dev
sudo apt-get install libglewmx-dbg

if [ -d "/usr/lib/x86_64-linux-gnu" ]
then
    	echo "This is 64bit OS and Copying necessary library files 		to /usr/lib"
	
	#Glut
	sudo cp /usr/lib/x86_64-linux-gnu/libglut.a /usr/lib
	sudo cp /usr/lib/x86_64-linux-gnu/libglut.so /usr/lib
	sudo cp /usr/lib/x86_64-linux-gnu/libglut.so.3 /usr/lib
	sudo cp /usr/lib/x86_64-linux-gnu/libglut.so.3.9.0 /usr/lib

	#Glu
	sudo cp /usr/lib/x86_64-linux-gnu/libGLU.a /usr/lib
	sudo cp /usr/lib/x86_64-linux-gnu/libGLU.so /usr/lib
	sudo cp /usr/lib/x86_64-linux-gnu/libGLU.so.1 /usr/lib
	sudo cp /usr/lib/x86_64-linux-gnu/libGLU.so.1.3.1 /usr/lib
else
    	echo "This is 32bit OS and Copying necessary library files 		to /usr/lib"
	
	#Glut
	sudo cp /usr/lib/i386-linux-gnu/libglut.a /usr/lib
	sudo cp /usr/lib/i386-linux-gnu/libglut.so /usr/lib
	sudo cp /usr/lib/i386-linux-gnu/libglut.so.3 /usr/lib
	sudo cp /usr/lib/i386-linux-gnu/libglut.so.3.9.0 /usr/lib

	#Glu
	sudo cp /usr/lib/i386-linux-gnu/libGLU.a /usr/lib
	sudo cp /usr/lib/i386-linux-gnu/libGLU.so /usr/lib
	sudo cp /usr/lib/i386-linux-gnu/libGLU.so.1 /usr/lib
	sudo cp /usr/lib/i386-linux-gnu/libGLU.so.1.3.1 /usr/lib

fi

echo "Installing Codeblocks IDE"

sudo apt-get install codeblocks

echo "<<<<<< Your environment is ready now >>>>>>"

echo " Now open codeblocks, choose glut project and put /usr as glut location and start writing your opengl programs. HAPPY CODING "


